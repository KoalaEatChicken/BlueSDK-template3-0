//
//  ipHG24D6Fs_Result_pDiG.h
//  BlueDanube
//
//  Created by dyH8gTL0hA on 2018/3/5.
//  Copyright © 2018年 Ovuz27tCAL . All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cKsoz59IjJ7dErP1_OpenMacros_s7Ijo1.h"

/** 通知：登出成功 */
extern NSString * _Nonnull const KKNotiLogoutSuccessNoti;

/* 悬浮球的初始位置 */
typedef NS_ENUM(NSInteger, FloatBallStyle) {
    
    FloatBallStyleDefault,
    FloatBallStyleCenterLeft,
    FloatBallStyleCenterRight,
    FloatBallStyleTopLeft,
    FloatBallStyleTopRight,
    FloatBallStyleBottomLeft,
    FloatBallStyleBottomRight,
};

/* 制服结果的状态码 */
typedef NS_ENUM(NSInteger, KKSettleBillStatus) {
    
    /** 失败  */
    KKSettleBillStatusFailure,
    
    /** 移动端内购成功的回调，但是制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusIapSuccess,
    
    /** 移动端third part制服成功的回调（由于xx原因，这个回调暂时不会调用），制服是否成功，要以服务器的回调为准  */
    KKSettleBillStatusSuccess,
    
    /** 第三方制服，制服完成时回调到；具体成功与否，要以服务器的回调为准  */
    KKSettleBillStatusNotConfirm,
    
    /** 第三方制服，用户取消制服  */
    KKSettleBillStatusUserCancel,
};


@interface KKResult : NSObject

@property(nonatomic, strong) NSObject *ykwTnuOchergbdfNyGjCF;
@property(nonatomic, strong) NSNumber *mlnXfuhdxFNviOkjZAQgbJGPD;
@property(nonatomic, strong) NSNumber *fmwFhIPXusnitCHVAWNzLxTkvp;
@property(nonatomic, strong) NSNumber *jctonPkjcIvsS;
@property(nonatomic, strong) NSObject *wzIxsCrfatmYSTWBUFRqHVwQeO;
@property(nonatomic, strong) NSMutableDictionary *jyBJbiUlVOLoKPkxyRejNh;
@property(nonatomic, strong) NSDictionary *ybKgIhoxHGwaqLCnWMtSXfikeD;
@property(nonatomic, strong) NSMutableDictionary *odQBMwtURqzvJuaCLlWhogVsE;
@property(nonatomic, strong) NSDictionary *wiJKxLyCPcUuIWY;
@property(nonatomic, strong) NSMutableDictionary *muWRpQSoTFOqtrAIYNjVXZvleu;
@property(nonatomic, strong) NSNumber *imAhrVfRJDqmlUvxj;
@property(nonatomic, strong) NSArray *grcnPJyVBTvojKYldhrzpmubF;
@property(nonatomic, strong) NSMutableDictionary *wxZTIWcREULSpqQMwazbC;
@property(nonatomic, strong) NSArray *dtnLFIyPGfCcOxkNejdlMomhtJW;
@property(nonatomic, strong) NSDictionary *jkuHwPmDWlRekZzQMAIFany;
@property(nonatomic, strong) NSNumber *tvtSoUedhBbXAvLWOEY;
@property(nonatomic, strong) NSMutableDictionary *qmvYsQCeUBGPDFnOgHSKfrZTo;
@property(nonatomic, strong) NSNumber *ihbAKYuqgNkzILwrjVOS;
@property(nonatomic, strong) NSDictionary *sdPhlbkIRtKyQZXuN;
@property(nonatomic, strong) NSMutableArray *vfukyXThNUGaQOHWdzD;
@property(nonatomic, strong) NSNumber *gwqMbdnRKxjZNavCrD;
@property(nonatomic, copy) NSString *taZulNpHyVdYfXcSCJObRAvg;
@property(nonatomic, strong) NSObject *kqqtXpPWAZuzmC;
@property(nonatomic, strong) NSNumber *qdYqMZioJIECRnsdXrzfaxPDmGg;
@property(nonatomic, strong) NSMutableArray *cbQXoOBryvNtkm;
@property(nonatomic, copy) NSString *xceLsjBkahMl;
@property(nonatomic, strong) NSNumber *kzUkAETieFWrRQlj;
@property(nonatomic, strong) NSDictionary *mntIGiBjPlxbHsMLJku;
@property(nonatomic, strong) NSNumber *vnuwiQTaKfnNchlvxqMom;
@property(nonatomic, strong) NSNumber *qmMRzOWLNsKtZuy;
@property(nonatomic, copy) NSString *hngPjZnLANTXQv;
@property(nonatomic, strong) NSDictionary *atFTYsEKpaPeQLNnjhBmxRif;
@property(nonatomic, strong) NSObject *bqMpcxBSaLOgqyz;



/**
 ture表示成功
 */
@property(copy, nonatomic) NSString * _Nullable result;
@property(copy, nonatomic) NSString *_Nullable msg;
@property(strong, nonatomic) id _Nullable data;

- (BOOL)isSucc;


/**
 获得一个reslut对象

 @param result result
 @param data data
 @param msg msg
 @return result对象
 */
+ (instancetype _Nonnull)resultWithResult:(nullable NSString *)result data:(nullable id)data msg:(nullable NSString *)msg;

@end

typedef void(^KKCompletionHandler)(KKResult * _Nonnull result);
