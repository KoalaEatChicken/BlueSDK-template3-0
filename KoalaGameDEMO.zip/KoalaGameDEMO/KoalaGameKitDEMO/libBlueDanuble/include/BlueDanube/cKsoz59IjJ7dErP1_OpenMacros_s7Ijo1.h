#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala kGmuckzViWZFE
#define KKUser Mp6Sx0Ay3F_Ih
#define KKOrder EZ3soCqjtwlUPG
#define KKRole QRlyMXSHwvjqC49Yc
#define KKResult _dz04G_SVyjsJP
#define KKConfig SqI2eBSPL0WD
#define kgk_loginWithViewController URqMfSIEOinTurBCax
#define kgk_demo_setPkver YviNmBzb1uGh5wIZES4J
#define kgk_switchAccounts LV6zT2SO3UW
#define kgk_postRoleInfoWithModel zepdkjL5CVtfcKEz
#define kgk_initGameKitWithCompletionHandler nYr4G2W5q8DP7ThO
#define kgk_openLog FKmQZ9rn1achOJeI
#define kgk_settleBillWithOrder YhmR8vbpDcH

#endif
