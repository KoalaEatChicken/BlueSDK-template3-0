//
//  JJsluiznbvT_Role_nvzJ.h
//  BlueDanube
//
//  Created by dyH8gTL0hA on 2018/4/27.
//  Copyright © 2018年 Ovuz27tCAL . All rights reserved.
//
//角色统计模型
#import <Foundation/Foundation.h>
#import "cKsoz59IjJ7dErP1_OpenMacros_s7Ijo1.h"

@interface KKRole : NSObject

@property(nonatomic, strong) NSNumber *hkKQBqUnErSzRGkY;
@property(nonatomic, strong) NSArray *eaozFEiMWaVdL;
@property(nonatomic, strong) NSArray *qemfUVGkaJTOPuvgNQ;
@property(nonatomic, strong) NSNumber *lzDkUqwPtKxAblrXeMscySaQvE;
@property(nonatomic, strong) NSNumber *znutoMrVlAxONqBRwZPkLS;
@property(nonatomic, strong) NSDictionary *acNtfLxMObQToUVKmscG;
@property(nonatomic, strong) NSMutableDictionary *xknGwWgNDdQXcSpqKMFke;
@property(nonatomic, strong) NSDictionary *ixpBgOSknXUYvrTJClwu;
@property(nonatomic, strong) NSArray *psqltAwBmuEpIgHOYjiUyNKLf;
@property(nonatomic, copy) NSString *fgdqwzVCmtQIufgxHBEXZs;
@property(nonatomic, strong) NSMutableArray *qnZeMcpQuKvIzYdT;
@property(nonatomic, copy) NSString *bsuLUwsINzetMSDOWTfRJGYbgAC;
@property(nonatomic, strong) NSNumber *cfUMxfJaZjToNH;
@property(nonatomic, copy) NSString *ihcMhnNHRICEgUTidmesGyAQkO;
@property(nonatomic, strong) NSNumber *udJMZIiPsBjwt;
@property(nonatomic, strong) NSDictionary *jisyjdfGWaNhbgUun;
@property(nonatomic, strong) NSDictionary *rqktrScoCWpzniHvwdBsI;
@property(nonatomic, strong) NSMutableArray *zrixOVUQupjkLZ;
@property(nonatomic, strong) NSArray *awetDgTAowUBmYjPNlCrxSi;
@property(nonatomic, copy) NSString *qzCQqKdUAHWaSsZiVJu;
@property(nonatomic, strong) NSNumber *zfWQVqPNhuDtfELB;
@property(nonatomic, strong) NSMutableArray *xcBKWfZxFoLzIqlr;
@property(nonatomic, strong) NSArray *bfzGpvJngSFxLIalshr;
@property(nonatomic, strong) NSNumber *sukiHYSjWzQMCGDlmJTn;
@property(nonatomic, strong) NSDictionary *gjzMkLBVGqsNRrJjbFlyDI;
@property(nonatomic, strong) NSObject *lnJLrajWdGpPuSEvUKiT;
@property(nonatomic, strong) NSArray *oyGkBuOfIJXLnw;
@property(nonatomic, strong) NSNumber *dgHETRWkwlNPzBJegv;
@property(nonatomic, strong) NSMutableArray *qrYqjBJicMXaS;
@property(nonatomic, strong) NSMutableArray *mwBUXjriMRVsoaGSywzQY;
@property(nonatomic, strong) NSMutableDictionary *viOmjeRbXDZcGyiwskPaNgEYBdo;
@property(nonatomic, strong) NSMutableDictionary *zmzQTgBNUXOqvPupKM;
@property(nonatomic, strong) NSNumber *gbmDwzNKATWghPndjFiBHpV;
@property(nonatomic, strong) NSMutableArray *fcVtdNkQpjhosxmvinCEb;
@property(nonatomic, strong) NSDictionary *umaHVCkowBUfK;
@property(nonatomic, strong) NSObject *xkFbhgGDoUSlXadYfCv;

/** 区服id */
@property(nonatomic, copy) NSString *serverid;

/** 区服名称 */
@property(nonatomic, copy) NSString *servername;

/** 角色ID */
@property(nonatomic, copy) NSString *roleid;

/** 角色名称 */
@property(nonatomic, copy) NSString *rolename;

/** 角色等级 */
@property(nonatomic, copy) NSString *rolelevel;
@end
