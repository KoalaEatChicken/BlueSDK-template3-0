//
//  main.m
//  KoalaGameKitDEMO
//
//  Created by kaola  on 2018/5/11.
//  Copyright © 2018年 kaola . All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
